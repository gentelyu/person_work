#!/bin/bash


for ((i = 1; i <= 3; i++))
do
    ./virus &
done

